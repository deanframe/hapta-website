# hapta-website

Website of the Holly Avenue Elementary School PTA, still a work in progress.

This is my first experience with web development, so it is very simple and uses just HTML and CSS.
